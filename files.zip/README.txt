1. Скопіюй у одну папку на сервері: bot.py, card.py, Dockerfile, docker-compose.yml
   (Dockerfile збирається з цієї ж папки), створи .env за зразком .env.example.
2. docker compose up -d --build
3. Логи: docker compose logs -f   |  Оновлення коду: замінити файли і docker compose up -d --build
База loe_bot.db лежить у ./data (не видаляй, там підписки).
